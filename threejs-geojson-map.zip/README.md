参考链接：

[Three.js 3D 地图可视化](https://juejin.cn/post/6844904054896885768)