(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f6ee08fd._.js",
  "static/chunks/node_modules_three_build_three_core_df0bde7e.js",
  "static/chunks/node_modules_three_build_three_module_230a9f89.js",
  "static/chunks/node_modules_three_examples_jsm_controls_OrbitControls_e8a02b13.js",
  "static/chunks/node_modules_1018a99d._.js"
],
    source: "dynamic"
});
