(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__608acd83._.css",
  "static/chunks/node_modules_next_dist_05476590._.js",
  "static/chunks/components_theme-provider_tsx_d43e95ea._.js"
],
    source: "dynamic"
});
